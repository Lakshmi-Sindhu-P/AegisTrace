"""Append-only review history.

The architecture requires that corrections create new history rather than overwriting earlier
records. That is enforced in two places: :class:`~aegistrace.schemas.review.ReviewHistory` validates
the chain on every construction path, and this module's :func:`append_review` additionally rejects a
bad append *before* building a new history. A review may only supersede the most recent review, and
duplicate identifiers are rejected. The result is a linear chain in which the last entry is
unambiguously current and every earlier belief remains readable.

The schema check is the one that matters for stored records: durable histories are read back with
``ReviewHistory.model_validate(...)``, which never calls :func:`append_review`. Before that check
existed, a history whose links dangled or forked loaded without complaint.
"""

from __future__ import annotations

from uuid import UUID

from aegistrace.schemas.review import HumanReview, ReviewHistory


def new_history(subject_triage_id: UUID) -> ReviewHistory:
    """Start an empty history for one triage subject."""

    return ReviewHistory(subject_triage_id=subject_triage_id)


def append_review(history: ReviewHistory, review: HumanReview) -> ReviewHistory:
    """Append a review, enforcing that corrections extend the chain instead of rewriting it."""

    if review.subject_triage_id != history.subject_triage_id:
        raise ValueError("review subject does not match the history subject")

    if any(existing.review_id == review.review_id for existing in history.reviews):
        raise ValueError("a review with this identity is already recorded")

    if history.reviews:
        latest = history.reviews[-1]
        if review.supersedes_review_id is None:
            raise ValueError("a later review must supersede the most recent review")
        if review.supersedes_review_id != latest.review_id:
            raise ValueError("a review may only supersede the most recent review")
    elif review.supersedes_review_id is not None:
        raise ValueError("the first review in a history cannot supersede anything")

    # Constructed from fields rather than `model_copy`, so `ReviewHistory.validate_subjects_match`
    # actually runs. The manual check above stays as defence in depth, but it is no longer the only
    # guarantee: the schema is (issue #42).
    return ReviewHistory(
        subject_triage_id=history.subject_triage_id,
        reviews=(*history.reviews, review),
    )


def current_review(history: ReviewHistory) -> HumanReview | None:
    """Return the review currently in force, or None when nothing has been reviewed yet."""

    return history.reviews[-1] if history.reviews else None


__all__ = ["append_review", "current_review", "new_history"]
