"""Contract and output tests for the CTU-13 Argus-flow adapter."""

from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from pathlib import Path

import pyarrow.parquet as pq
import pytest

from aegistrace.ingestion import ctu13
from aegistrace.ingestion.ctu13 import (
    CTU13_DATASET_NAME,
    CTU13_SCENARIO_ID,
    parse_ctu13_binetflow,
    write_ctu13_ingestion_outputs,
)
from aegistrace.schemas.events import Ctu13FlowDetails, GroundTruthLabel

FIXTURE_PATH = Path("data/fixtures/ctu13/scenario_11.binetflow")
INGESTED_AT = datetime(2026, 9, 21, 1, 0, tzinfo=UTC)


def test_parse_ctu13_fixture_preserves_labels_scenario_and_argus_fields() -> None:
    result = parse_ctu13_binetflow(
        FIXTURE_PATH,
        ingested_at=INGESTED_AT,
        report_generated_at=INGESTED_AT,
    )

    assert len(result.events) == 4
    assert result.report.dataset_name == CTU13_DATASET_NAME
    assert result.report.rows_seen == 4
    assert result.report.accepted_rows == 4
    assert result.report.rejected_rows == 0
    assert result.report.label_distribution == {"malicious": 1, "benign": 1, "unknown": 2}
    assert result.report.source_label_distribution["flow=Background"] == 1
    assert result.report.missing_counts["dTos"] == 2
    assert result.report.flow_distributions["protocol"] == {"tcp": 2, "udp": 1, "icmp": 1}

    first = result.events[0]
    assert first.source.scenario_id == CTU13_SCENARIO_ID
    assert first.source.source_event_id == "line-2"
    assert first.observed_at.isoformat() == "2011-08-18T13:39:35.087798+00:00"
    assert first.ground_truth_label is GroundTruthLabel.MALICIOUS
    assert first.attack_category == "flow=From-Botnet-V52-1-TCP"
    assert isinstance(first.details, Ctu13FlowDetails)
    assert first.details.network_bytes == 1000
    assert first.details.source_tos == 0
    assert first.details.source_label == "flow=From-Botnet-V52-1-TCP"
    assert "source_timestamp_timezone_assumed:Europe/Prague" in first.provenance.quality_flags

    background = result.events[2]
    assert background.ground_truth_label is GroundTruthLabel.UNKNOWN
    assert background.attack_category is None
    assert background.label_source == "ctu13_stratosphere_label"


def test_reingestion_is_deterministic() -> None:
    first = parse_ctu13_binetflow(FIXTURE_PATH, ingested_at=INGESTED_AT)
    second = parse_ctu13_binetflow(FIXTURE_PATH, ingested_at=INGESTED_AT)

    assert [event.event_id for event in first.events] == [event.event_id for event in second.events]
    assert first.report.raw_checksum == second.report.raw_checksum


def test_outputs_are_typed_parquet_json_and_manifest(tmp_path: Path) -> None:
    result = parse_ctu13_binetflow(
        FIXTURE_PATH, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    )
    parquet_path = tmp_path / "events.parquet"
    report_path = tmp_path / "quality_report.json"
    manifest_path = tmp_path / "dataset_manifest.json"

    manifest = write_ctu13_ingestion_outputs(
        result,
        input_path=FIXTURE_PATH,
        parquet_path=parquet_path,
        report_path=report_path,
        manifest_path=manifest_path,
    )

    table = pq.read_table(parquet_path)
    assert table.num_rows == 4
    assert table.schema.field("observed_at").type.tz == "UTC"
    assert table.schema.field("source_label").nullable is False
    assert json.loads(report_path.read_text())["accepted_rows"] == 4
    assert json.loads(manifest_path.read_text())["manifest_id"] == str(manifest.manifest_id)
    assert manifest.selected_scenarios == (CTU13_SCENARIO_ID,)


def test_duplicate_rows_are_rejected_and_reported(tmp_path: Path) -> None:
    lines = FIXTURE_PATH.read_text().splitlines()
    duplicate = tmp_path / "duplicate.binetflow"
    duplicate.write_text("\n".join([lines[0], lines[1], lines[1], *lines[2:]]) + "\n")

    result = parse_ctu13_binetflow(
        duplicate, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    )

    assert result.report.accepted_rows == 4
    assert result.report.rejected_rows == 1
    assert result.report.duplicate_source_records == 1
    assert result.report.issues[0].issue_type == "duplicate_source_record"


def test_malformed_and_invalid_rows_are_safe(tmp_path: Path) -> None:
    malformed = tmp_path / "malformed.binetflow"
    lines = FIXTURE_PATH.read_text().splitlines()
    malformed.write_text(
        "\n".join(
            [
                lines[0],
                "bad,csv",
                (
                    "2011/08/18 15:39:35.0,1,tcp,192.0.2.1,1,->,198.51.100.1,2,SF,"
                    "0,0,1,10,5,flow=Background"
                ),
                (
                    '2011/08/18 15:39:35.0,1,tcp,"unterminated,1,->,198.51.100.1,2,SF,'
                    "0,0,1,10,5,flow=Background"
                ),
            ]
        )
        + "\n"
    )

    result = parse_ctu13_binetflow(
        malformed, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    )

    assert len(result.events) == 1
    assert result.report.rejected_rows == 2
    assert {issue.issue_type for issue in result.report.issues} == {"malformed_row"}
    assert "unterminated" not in result.report.model_dump_json()


def test_invalid_header_and_missing_label_are_rejected(tmp_path: Path) -> None:
    invalid_header = tmp_path / "invalid-header.binetflow"
    invalid_header.write_text("not,a,ctu,header\n1,2,3,4\n")
    result = parse_ctu13_binetflow(
        invalid_header, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    )
    assert result.events == ()
    assert result.report.rejected_rows == 2

    missing_label = tmp_path / "missing-label.binetflow"
    line = FIXTURE_PATH.read_text().splitlines()[1].rsplit(",", maxsplit=1)[0]
    missing_label.write_text(f"{FIXTURE_PATH.read_text().splitlines()[0]}\n{line},-\n")
    result = parse_ctu13_binetflow(
        missing_label, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    )
    assert result.events == ()
    assert result.report.issues[0].issue_type == "invalid_record"


def test_cli_main_writes_three_artifacts(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    output_dir = tmp_path / "cli-output"
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "ingest_ctu13",
            "--input",
            str(FIXTURE_PATH),
            "--output-dir",
            str(output_dir),
            "--ingested-at",
            INGESTED_AT.isoformat(),
            "--report-generated-at",
            INGESTED_AT.isoformat(),
            "--raw-reference",
            "data/raw/ctu13/CTU-Malware-Capture-Botnet-52/capture20110818-2.binetflow",
        ],
    )

    assert ctu13.main() == 0
    assert (output_dir / "events.parquet").exists()
    assert (output_dir / "quality_report.json").exists()
    assert (output_dir / "dataset_manifest.json").exists()


def test_direct_normal_and_botnet_labels_and_timezone_argument(tmp_path: Path) -> None:
    source = FIXTURE_PATH.read_text().replace("flow=From-Botnet-V52-1-TCP", "Botnet", 1)
    source = source.replace("flow=From-Normal-V52-Grill", "Normal", 1)
    path = tmp_path / "direct-labels.binetflow"
    path.write_text(source)
    result = parse_ctu13_binetflow(
        path,
        ingested_at=INGESTED_AT,
        source_timezone="UTC",
        report_generated_at=INGESTED_AT,
    )

    assert result.events[0].ground_truth_label is GroundTruthLabel.MALICIOUS
    assert result.events[1].ground_truth_label is GroundTruthLabel.BENIGN
    assert result.events[0].observed_at.isoformat() == "2011-08-18T15:39:35.087798+00:00"


def test_issue_39_rejected_rows_counts_issues_not_data_rows(tmp_path: Path) -> None:
    """Pin the real meaning of `rejected_rows`, so the arithmetic is not mistaken for a bug.

    Issue #39 was filed as an over-count. It is not: `rejected_rows` is defined as the number of
    recorded issues, which is why an invalid header is counted here even though it is not a data
    row. The CLI relies on exactly this via `fail_on_rejects`. The name is what misleads, so the
    contract is pinned here and documented on the field.
    """

    invalid_header = tmp_path / "invalid-header.binetflow"
    invalid_header.write_text("not,a,ctu,header\n1,2,3,4\n")

    report = parse_ctu13_binetflow(
        invalid_header, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    ).report

    # The established contract: one issue per problem, and one header plus one row is two problems.
    assert report.rejected_rows == len(report.issues) == 2
    assert report.rows_seen == 1, "rows_seen counts DATA rows, excluding the header"
    # The consequence the field's name hides. Asserted so a future change to it is a decision.
    assert report.accepted_rows + report.rejected_rows != report.rows_seen
    assert report.accepted_rows + report.rejected_rows > report.rows_seen


def test_issue_39_valid_header_with_no_data_rows_is_self_consistent(tmp_path: Path) -> None:
    """The arithmetic DOES hold whenever no structural problem is reported."""

    header_only = tmp_path / "header-only.binetflow"
    header_only.write_text(FIXTURE_PATH.read_text().splitlines()[0] + "\n")

    report = parse_ctu13_binetflow(
        header_only, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    ).report

    assert (report.rows_seen, report.accepted_rows, report.rejected_rows) == (0, 0, 0)
    assert report.accepted_rows + report.rejected_rows == report.rows_seen


# --- Issue #37: a zero-accept ingest must not report success --------------------------------


def _cli_argv(source: Path, output_dir: Path, *extra: str) -> list[str]:
    return [
        "ingest_ctu13",
        "--input",
        str(source),
        "--output-dir",
        str(output_dir),
        "--ingested-at",
        INGESTED_AT.isoformat(),
        "--report-generated-at",
        INGESTED_AT.isoformat(),
        "--raw-reference",
        "data/raw/ctu13/CTU-Malware-Capture-Botnet-52/capture20110818-2.binetflow",
        *extra,
    ]


def test_issue_37_empty_but_valid_source_exits_non_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    """An empty-but-valid input used to report a clean success over zero rows.

    The header parses, no row is rejected, and the run looked identical to a real ingest. It is
    now refused, and the refusal is NOT gated on `--fail-on-rejects`: no flag should be needed to
    notice that nothing was ingested.
    """

    header_only = tmp_path / "header-only.binetflow"
    header_only.write_text(FIXTURE_PATH.read_text().splitlines()[0] + "\n")

    monkeypatch.setattr(sys, "argv", _cli_argv(header_only, tmp_path / "out"))
    exit_code = ctu13.main()

    captured = capsys.readouterr()
    assert exit_code != 0, "a zero-row ingest must not exit 0"
    assert "accepted_rows" in captured.out, "the machine-readable summary is still emitted"
    assert "no accepted rows" in captured.err, "the refusal must say why"
    # Diagnostics are preserved: the run still wrote its report and manifest.
    assert (tmp_path / "out" / "quality_report.json").exists()
    assert (tmp_path / "out" / "dataset_manifest.json").exists()


def test_issue_37_all_rows_rejected_exits_non_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    """The other zero-accept route: rows were present but every one was rejected."""

    source = tmp_path / "all-bad.binetflow"
    source.write_text(FIXTURE_PATH.read_text().splitlines()[0] + "\nnot-a-valid-row\n")

    monkeypatch.setattr(sys, "argv", _cli_argv(source, tmp_path / "out"))
    exit_code = ctu13.main()

    captured = capsys.readouterr()
    assert exit_code != 0
    assert "no accepted rows" in captured.err
    # The rejection reason survives, which is what makes the failure diagnosable.
    assert "rejected" in captured.err


def test_issue_37_a_successful_ingest_still_exits_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The control, without which the tests above would pass for any always-failing CLI."""

    monkeypatch.setattr(sys, "argv", _cli_argv(FIXTURE_PATH, tmp_path / "out"))
    assert ctu13.main() == 0


def test_issue_37_the_rule_is_not_gated_on_fail_on_rejects(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A run that ACCEPTED rows and rejected some is unaffected without the flag.

    This is the boundary the fix must not cross: rejecting some rows while accepting others is a
    normal, reportable outcome, not a failed ingest.
    """

    source = tmp_path / "mixed.binetflow"
    lines = FIXTURE_PATH.read_text().splitlines()
    source.write_text("\n".join([lines[0], *lines[1:3], "not-a-valid-row"]) + "\n")

    monkeypatch.setattr(sys, "argv", _cli_argv(source, tmp_path / "out"))
    assert ctu13.main() == 0, "accepted rows exist, so the ingest succeeded"

    # ... and the flag still turns the same run into a failure.
    monkeypatch.setattr(
        sys, "argv", _cli_argv(source, tmp_path / "out2", "--fail-on-rejects")
    )
    assert ctu13.main() != 0


def test_issue_37_the_shared_rule_is_one_definition() -> None:
    """The rule lives in exactly one place, so the two adapters cannot drift apart.

    A duplicate guard with a duplicated message is what made a falsification test vacuous
    elsewhere in this codebase, so the two CLIs are checked to delegate rather than restate.
    """

    from aegistrace.ingestion.report import ingestion_exit_code, ingestion_exit_reason

    report = parse_ctu13_binetflow(
        FIXTURE_PATH, ingested_at=INGESTED_AT, report_generated_at=INGESTED_AT
    ).report
    assert report.accepted_rows > 0

    # A successful run: no reason, exit 0.
    assert ingestion_exit_reason(report, fail_on_rejects=True) is None
    assert ingestion_exit_code(report, fail_on_rejects=True) == 0

    # Zero accepted rows: a reason and a non-zero code, regardless of the flag.
    empty = report.model_copy(update={"accepted_rows": 0, "rejected_rows": 0})
    for flag in (True, False):
        assert ingestion_exit_reason(empty, fail_on_rejects=flag) is not None
        assert ingestion_exit_code(empty, fail_on_rejects=flag) != 0
