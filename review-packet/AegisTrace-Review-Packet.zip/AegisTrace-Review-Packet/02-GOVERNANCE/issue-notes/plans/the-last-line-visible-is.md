The last line visible is:

> It is an **applied AI-s**

The file ends there mid-sentence (line 93). Please attach or paste the missing remainder so I can recover the intended data-source strategy without guessing.