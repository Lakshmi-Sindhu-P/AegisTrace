## State: DONE

Fixed and verified.

### Change

`src/aegistrace/features/behavioral.py`: `prior_connections` now reads `_HostState.recent`, a deque
mirroring the 60s prior-flow window, instead of scanning the host's whole 300s window on every event.
O(1) amortized, identical count.

### Proof of semantic equivalence

Rebuilt cached captures from raw and compared all 32 features plus the label column against the
frozen artifacts:

- capture 46: 129,832 rows — **IDENTICAL**
- capture 53: 325,471 rows — **IDENTICAL**

### Effect

Capture 54 (1,925,149 rows) went from >30 minutes (killed mid-run) to **248.65 s**.

### Regression test

`tests/test_features.py::test_behavioral_prior_connection_count_expires_at_sixty_seconds`

### Gate

`pytest` 71 passed / 90.59% coverage; `ruff` clean; `mypy` clean.

Performance fix only: no feature value, threshold, model, or frozen policy changed, and no held-out
data was consumed to derive it.

### Residual limitation

Captures above roughly 2M rows still exceed the 16 GB host memory during parsing. Capture 49
(2,954,230 rows) completed only after the battery runner released parsed events before materializing
the matrix; capture 44 (4,710,639 rows) remains unmeasured. Lifting this ceiling would need a
streaming or chunked parser and is not required for this issue.
