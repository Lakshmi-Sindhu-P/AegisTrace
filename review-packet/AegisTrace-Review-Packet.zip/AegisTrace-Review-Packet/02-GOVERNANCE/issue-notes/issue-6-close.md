## State: DONE

Held-out generalization check completed at the frozen policy
(`aegistrace-phase3-behavioral-rf-validation-frozen-v1`, threshold `0.20`) with **no threshold search
and no tuning**.

- Runner: `scripts/run_phase3_heldout_battery.py`
- Artifact: `data/evaluation/phase3_heldout/heldout_summary.json` (ignored)
- Design and results: `docs/phase3_heldout_design.md`

### Result

| Exam capture | Family | Relation | Labeled | Malicious | Prevalence | Precision | Recall | Unknown rows | Unknown alerts | Unknown share |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 48 (Sc7) | RBot | same family | 1,732 | 63 | 0.036 | 0.8182 | 0.1429 | 112,345 | 47,822 | 0.426 |
| 50 (Sc9) | Neris | same family | 214,880 | 184,987 | 0.861 | 0.9993 | 0.9987 | 1,872,622 | 806,968 | 0.431 |
| 49 (Sc8) | Murlo | unseen family | 78,766 | 6,127 | 0.078 | 0.4694 | 0.9675 | 2,875,464 | 1,004,819 | 0.349 |
| 54 (Sc13) | Virut | unseen family | 71,782 | 40,003 | 0.557 | 0.9597 | 0.4515 | 1,853,367 | 623,135 | 0.336 |

### Interpretation

- Transfer within training families is near-perfect (50 Neris: precision `0.9993`, recall `0.9987`).
- Unseen families fail **non-uniformly**: 49 (Murlo) collapses precision (`0.4694`) while 54 (Virut)
  collapses recall (`0.4515`). The failure mode is family-dependent, not a single weakness.
- Capture 48's recall (`0.1429`) rests on 63 malicious rows (9 caught) and is not a stable estimate.
- Unknown-label alert share is `33.6%`-`43.1%` on every capture, consistent with the validation
  pool's `43.7%` (`docs/phase3_evaluation_diagnosis.md`, Evidence 5).

### Deviations

- **Capture 44 was not measured.** Its working set exceeds the 16 GB host memory with the current
  parser (4,710,639 rows); it thrashed swap rather than completing. The four measured captures still
  give a balanced battery: two training families (RBot, Neris) and two unseen families (Murlo, Virut).
- Capture 48 was previously opened by the historical baseline at feature `1.0.0`. It is therefore
  labelled "previously opened for the historical baseline; held out from the current frozen policy".
  Including it consumed the one-time Scenario 7 opening.

### Blocker encountered and fixed

Feature building for large captures was blocked by a superlinear prior-window scan (see #9). Fixed
with a provably output-identical O(1) mirror deque.

### Proof

- `pytest` 71 passed / 90.59% coverage; `ruff check .` clean; `mypy` clean (27 source files).
- Feature-pipeline reproducibility: rebuilding captures 46 (129,832 rows) and 53 (325,471 rows) from
  raw reproduces the frozen artifacts exactly across all 32 features plus the label column.

No threshold, model, feature, or frozen policy changed, and no tuning followed the result.
