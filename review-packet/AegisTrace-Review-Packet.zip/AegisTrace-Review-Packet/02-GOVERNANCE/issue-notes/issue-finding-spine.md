State: PROPOSED — the next product layer, independent of the held-out detector check.

Objective
Build the provenance-preserving investigation spine that every later capability depends on: versioned detector records, deterministic finding aggregation, immutable evidence bundles, and claim verification.

Why
The amended research target (multi-model investigation with independent AI review) cannot be evaluated until findings and evidence bundles exist. The project rule is: no LLM triage before findings and evidence bundles.

Scope
1. Emit ML/SVM outputs as versioned DetectionResult records with preserved score semantics (no cross-model score comparison).
2. Finding schema plus deterministic, label-free aggregation by host/time/destination/port; preserve every event ID, detection ID, score, rule, and feature version.
3. Immutable EvidenceBundle per docs/architecture.md.
4. Provenance-preservation, grouping-stability, and label-leakage tests.
5. Claim-verification layer with the claim-type taxonomy (OBSERVED_FACT, DETERMINISTIC_DERIVATION, REFERENCE_BACKED_FACT, MODEL_INFERENCE, AI_INTERPRETATION, UNKNOWN_INSUFFICIENT_EVIDENCE).

Out of scope
- No LLM, no fusion, no UI, no Scenario 7, and no change to the frozen detector policy.

Acceptance criteria
- An integration test traces event -> detection -> finding -> evidence bundle without losing provenance.
- Grouping is stable under small time-window changes and never uses research labels.
- Full tests, Ruff, mypy, and validators pass.
