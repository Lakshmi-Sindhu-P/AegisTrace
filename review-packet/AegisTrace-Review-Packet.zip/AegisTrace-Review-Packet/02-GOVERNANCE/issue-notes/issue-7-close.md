## State: DONE

Milestone 5 is implemented and verified. No LLM, fusion, UI, or Scenario 7 was touched, and no
detector policy, feature builder, or existing schema field was changed.

### Delivered

| Scope item | Module |
|---|---|
| ML outputs as versioned `DetectionResult` with preserved score semantics | `src/aegistrace/detection/ml.py` |
| `Finding` schema + deterministic label-free aggregation | `src/aegistrace/schemas/findings.py`, `src/aegistrace/detection/findings.py` |
| Immutable `EvidenceBundle` | `src/aegistrace/detection/evidence.py`, `src/aegistrace/schemas/findings.py` |
| Claim verification with the claim-type taxonomy | `src/aegistrace/verification/claims.py` |
| Provenance, stability, and leakage tests | `tests/test_findings.py` |

### Acceptance criteria

**An integration test traces event -> detection -> finding -> evidence bundle without losing
provenance.** `test_event_to_detection_to_finding_to_bundle_preserves_provenance` asserts that every
finding `event_id` and `detection_id` resolves to a real event/detection, that the bundle's
`event_summaries` cover the finding's events exactly, and that each score reference carries the
model name and feature version.

**Grouping is stable under small time-window changes and never uses research labels.**

- `test_grouping_is_stable_across_window_changes_and_input_order`: two bursts separated by 540s with
  a 20s largest within-burst gap. Any window in (20, 540) must give the same two findings; windows
  120-500 are asserted byte-identical, and reversed input produces the same output.
- `test_aggregation_never_consults_research_labels`: three inputs identical except for
  `ground_truth_label` (benign / malicious / unknown) produce byte-identical findings.

**Full tests, Ruff, mypy, and validators pass.** `pytest` 80 passed / 90.85% coverage; `ruff check .`
clean; `mypy` clean on 33 source files; experiment registry (5 runs / 5 artifacts), solution
knowledge, Phase 3 evidence (Scenario 7 sealed), and agent-trace validators all pass.

### Design decisions a reviewer should check

1. **Gap-based grouping instead of fixed calendar buckets.** Fixed buckets make the grouping an
   artifact of where the grid falls, so nudging the window silently reshapes findings. Single-linkage
   by observed-time gap depends only on how far apart events actually are, which is what makes the
   stability claim checkable rather than asserted.
2. **Cross-model scores are never compared.** `ScoreReference` keeps detector identity, model
   identity, and the feature version. There is deliberately no API that ranks alerts across models;
   inventing one is a documented policy decision, not this module's job.
3. **`missing_context` and `limitations` are required contract fields.** A bundle that does not state
   what it lacks invites a reviewer to over-read it.
4. **An uncited claim is downgraded, not accepted.** `verify_claim` returns
   `UNKNOWN_INSUFFICIENT_EVIDENCE` with `verified=False` and never edits the original claim, so a
   wrong assertion stays visible in the record instead of being silently corrected.

### Process note

Three delegated attempts to implement this milestone failed or stalled with an empty working tree
(the first preferred model failed repeatedly; the second read the codebase then stalled and was
stopped; the third failed without writing). The working tree was verified clean between attempts, so
no partial or duplicated work was carried forward, and implementation was completed directly in the
main session.

Refs: commit `659d0e7`; local trace `.context/traces/phase3-milestone5-spine.jsonl` (6 records,
validated).
