Design decisions recorded 2026-10-08 from owner discussion:

**Goal framing**
- This is being pursued as a RESEARCH CONTRIBUTION, not a commercial product. The repo's portfolio-artifact objective remains, but the primary aim is a defensible finding about evidence-grounded, human-oversight-first AI triage.

**Split design (supersedes any random row-level split)**
- The unit of splitting is the whole capture, never the row. Random row splits leak because flows from the same host/time window are near-duplicates; the repo already mandates grouped splits in `docs/evaluation.md`.
- Two pools: a PRACTICE pool (train/validate; rotate the validation capture so we can iterate many times) and a SEALED EXAM pool (opened once, no changes afterward).
- Test BOTH a same-family capture (clean test of whether the learned pattern transfers) and a different-family capture (cross-family generality).
- Report every capture individually, never only a pooled average.

**Status**
- A bounded landscape scan and a read-only diagnostic pass (metric reconciliation, label audit, error inspection) are running. This issue's capture choice and final scope will be set after those results.
