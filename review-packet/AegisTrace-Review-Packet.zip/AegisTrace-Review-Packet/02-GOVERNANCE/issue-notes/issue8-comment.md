Research-landscape addendum (bounded, 2026-10-08)

A scan via the open OpenAlex index (seven topical queries; papers not read in full) found that "evidence-grounded LLM-assisted SOC investigation" is **already an occupied area** — e.g. *Argus: Evidence-Grounded LLM-Assisted Investigation for Security Operations Centers* (2026, https://doi.org/10.5281/zenodo.22259142) and *Insider Threat Detection and Evidence-Grounded Triage Using a Heterogeneous Dual-Branch Network and a Constrained LLM Agent* (2026, https://doi.org/10.3390/app16147054). LLM injection/hallucination risk inside the SOC is also actively studied.

Implication for this finding: the defensible contribution is **method and measurement**, not another triage system — evaluation under label scarcity (94.3% of validation rows are unlabelled here), unknown-label workload as a first-class result, and independently frozen dual-role adjudication that refuses agreement-as-truth.

Full scan: `docs/research_landscape.md`. Commercial products and market sizing were **not** verified because web search was unavailable; the scan is not a systematic review.
