## Stage 1 — `VALIDATED`, and the hypothesis is **REFUTED**

The expected result did not happen. Routing by uncertainty did **not** reach more true positives than
routing by model score. It lost on **every** capture, and on two captures it was worse than reviewing
alerts at random.

Commit `59e55c3`. Artifact `data/evaluation/phase3_analyst_replay/replay_summary.json`, sha256
`1d00ec29273207958d3a48d0c63b8b1a69fcc8e5d3375c342a2c59169a956abe`. Re-running the runner today
reproduces that digest **byte-for-byte** in 44 seconds, so the result is reproducible, not incidental.

### Numbers

True positives at a budget of 100 alerts (`model_score` / `uncertainty` / `random`):

| Capture | Family | Labeled | Malicious | TP@100 | AUC ms/un/rn |
|---|---|---|---|---|---|
| 46 | Neris (validation) | 5,561 | 901 | 100 / 84 / 13 | 0.994 / 0.576 / 0.524 |
| 53 | (validation) | 9,783 | 2,168 | 100 / 37 / 26 | 0.979 / 0.445 / 0.553 |
| 48 | RBot (previously opened) | 1,732 | 63 | 24 / 20 / 2 | 0.801 / 0.676 / 0.497 |
| **49** | **Murlo (held out)** | 78,766 | 6,127 | **100 / 8 / 9** | 0.982 / 0.179 / 0.508 |
| 50 | Neris (held out) | 214,880 | 184,987 | 100 / 96 / 84 | 1.000 / 0.758 / 0.878 |
| **54** | **Virut (held out)** | 71,782 | 40,003 | **100 / 59 / 60** | 0.982 / 0.727 / 0.693 |

Uncertainty beats model score in **0 of 6** captures. On 49 and 54 it does not even beat random.

### Interpretation

Boundary-adjacent alerts skew **benign** on these captures. Spending a scarce review budget on
threshold-adjacent alerts spends it where the model cannot separate the classes — and those rows are
mostly harmless. Threshold distance is therefore not merely uninformative here; it is
anti-correlated with maliciousness at the top of the queue.

### Scope of the refutation — do not over-read this

Refuted: **threshold-distance** uncertainty as a routing signal, for this detector, on these captures.

Not refuted: predictive entropy, ensemble disagreement, or calibration-based uncertainty. Those are
different operationalizations and were never tested. Any future attempt is a new experiment with its
own hypothesis, not a continuation of this one.

### Consequences

1. The honest headline is a **negative result**. Model-score ordering is the strongest available
   routing signal here, and the uncertainty signal that motivated Stage 1 actively misleads.
2. Stage 2 must treat `model_score` as the **incumbent baseline** to beat, not an also-ran.
3. Stage 3's literature should be read for which alert properties predict analyst usefulness.
   This result suggests decision-boundary proximity is not one of them.
4. No tuning followed the result, and none may: the detector policy and threshold remain frozen.

### Boundary, restated

This measures the value of the **routing** of already-computed scores. It is not a study of human
cognition and supports no claim about analyst behaviour, over-reliance, trust calibration, or
automation bias. Unknown-label rows were excluded from every metric and never counted as false
positives. Each capture was evaluated separately; no pooled figure is reported.
