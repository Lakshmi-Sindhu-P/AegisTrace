## Status: `BLOCKED_HUMAN` — provider run deferred, per owner condition

The owner approved the provider conditionally: freeze the exact configuration and establish
reproducibility, data-egress restrictions, a bounded budget, and independent execution; run a smoke
test first; and **defer execution and report the blocker if privacy or independence cannot be
established**. Two conditions fail, so the run is deferred. Nothing was sent to any provider;
measured spend is zero.

The frozen configuration is recorded in `configs/triage_provider_freeze.json` (`BLOCKED_HUMAN`). The
frozen detector policy is untouched.

### Condition 1 — provider access: not established

The repository has no LLM client and no credential path.

- `pyproject.toml` declares only `pyarrow`, `pydantic`, `scikit-learn`.
- No HTTP or LLM client exists anywhere in `src/`.
- `src/aegistrace/config.py:68` states that only **non-secret** settings are supported, and
  `logging_config.py` exists partly to redact secrets — the project deliberately has no secret
  handling yet.

Adding an LLM client and a credential path is a new dependency **and** a secret-handling decision.
Both are owner decisions, not agent decisions.

### Condition 2 — assessor independence: not established

This is the more serious one, because it goes to the research claim itself.

Both available providers advertise the **identical five models** — they are mirrors, not independent
sources. The only two models verified to work are `deepseek-v4-flash` and `deepseek-v4.1-flash`,
which are variants of the **same family**.

Two prompts over one model is not independence. Agreement between two instances of one model would
measure the model, not the assessors — which is exactly the variable this milestone exists to study.
No available pairing clears the bar.

### Egress audit: performed, not assumed

A real `EvidenceBundle` was built from the committed fixture and the exact canonical snapshot a
provider would receive was inspected.

**Clean:** 1685 bytes; no ground-truth label, no raw payload, no file path, no scenario identifier.
The single `"label"` string is the bundle stating that labels are deliberately excluded.

**Residual:** IP addresses do reach the snapshot. That is inherent — host identity is the grouping
key — and CTU-13 is a public published dataset, so these addresses are already public. Egressing them
is a governance decision, and the provider's retention and training-use terms must be recorded before
any first call.

### What is complete and unaffected

The corpus, schemas, isolation, assessment admission, and deterministic agreement engine are done and
independent of this decision. Milestone 7 cannot close, but nothing else is held up by it.

### What is needed from the owner

Designate the two assessor configurations and approve a credential path, **or** approve deferring the
run. If the second, the honest framing is that the project ships a frozen A/B triage *harness* with
the provider run unexecuted — which is still a defensible contribution, but it must be stated that
way and not implied to be a result.
