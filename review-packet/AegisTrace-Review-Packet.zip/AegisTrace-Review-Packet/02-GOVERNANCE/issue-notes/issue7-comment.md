Scope updated 2026-10-08 for the RESEARCH CONTRIBUTION goal.

**Hard acceptance criterion (owner requirement)**
- No code path may take an automated response action. The system may observe, aggregate, verify, and recommend; a human decides and acts. This must be *enforceable and testable* (a test that fails if any response/blocking path is introduced), not merely documented.

**Framing**
- The deliverable is a defensible finding about evidence-grounded, human-oversight-first triage, plus the reproducible artifact. It is not a commercial product and makes no production or prevention claim.

**Dependencies**
- Scope and sequencing will be finalized after the running read-only diagnostics (metric reconciliation, label audit, error inspection) and the landscape scan. If the detector's binding constraint turns out to be the metric or the alert-volume policy rather than the model, the detector assumptions in this issue may change.
