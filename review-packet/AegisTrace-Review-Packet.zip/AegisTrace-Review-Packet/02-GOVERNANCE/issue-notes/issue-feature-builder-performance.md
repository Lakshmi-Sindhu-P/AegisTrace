## State: IN_PROGRESS

## Problem

Building behavioral `1.1.0` features for the held-out exam captures (44/49/50/54, 263-640 MB) did
not complete in roughly 55 minutes even for the first capture. The same builder had previously
processed every cached capture (largest 179 MB / 1.3 M rows) in reasonable time, so the exam
captures were assumed to be merely large.

## Cause

`build_ctu13_behavioral_features` computed `prior_connections` as

```python
sum(flow.observed_at > connection_cutoff for flow in state.flows)
```

scanning the host's entire 300 s window on every event. For a host with F flows inside one window
the total work is O(F^2). Normal captures have small windows, so the cost stayed invisible;
spam/botnet captures (for example Virut) produce bursts large enough to make a single capture take
hours.

Measured: 129,832 rows (capture 46) built in 15.8 s (~8.2 k rows/s), so 1.9 M rows should take about
four minutes. Capture 54 exceeded 30 minutes, which is superlinear.

## Solution

Maintain a second deque `_HostState.recent` that mirrors the 60 s prior-flow window in insertion
order. Pop expired entries from the left, then `prior_connections = len(state.recent)`. This is the
identical count in O(1) amortized time.

## Proof of semantic equivalence

Rebuilt two cached captures from raw and compared every one of the 32 features plus the label column
against the frozen cached artifacts:

- capture 46: 129,832 rows, **IDENTICAL**
- capture 53: 325,471 rows, **IDENTICAL**

Method: `scripts/run_phase3_heldout_battery.py --features-only --feature-dir data/evaluation/phase3_heldout_repro`,
then column-wise `pyarrow.Table.equals` against `data/evaluation/phase3_model_stability/`.

## Gate

`pytest` 70 passed / 90.49% coverage; `ruff check .` clean; `mypy` clean (27 source files).

## Note

This is a performance fix, not a methodology change: no feature value, threshold, model, or frozen
policy changed, and no held-out data was consumed to derive it.
