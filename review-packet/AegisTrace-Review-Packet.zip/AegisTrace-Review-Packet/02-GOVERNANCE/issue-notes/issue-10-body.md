## State: APPROVED — not started

Program doc: [`docs/analyst_outcome_program.md`](../blob/main/docs/analyst_outcome_program.md),
approved 2026-10-08 by the owner.

### Objective

Produce defensible analyst-decision-outcome evidence without a live analyst study, in three ordered
stages.

### Why

No cyber-domain contacts are available to run a human study. The one available expert is of a very
high standard and time-constrained, so the project must exhaust its own options first and involve that
expert only to independently verify a *completed* method — not to rescue an unfinished one.

### Scope

1. **Decision-theoretic replay** on already-held labels: given a reviewer budget `K`, compare ranking
   by model score vs. uncertainty vs. random vs. oracle. Metrics: true positives at `K`,
   alerts-to-target-recall, coverage-curve area, reported per capture.
2. **Deterministic reviewer simulation**: encode reviewer policies as explicit rules and sweep
   strictness × budget × routing policy; report escalation rate, false-escalation rate,
   missed-detection rate, and reviewer load.
3. **Secondary analysis of published human-factors data**: use published alert-triage studies only to
   bound Stage 2's parameter ranges.

### Out of scope

- No human participants, no recruitment, no ethics submission.
- No change to the frozen detector policy.
- No claim of human decision quality, analyst behaviour, over-reliance, automation bias, or real SOC
  outcomes from Stages 1-3.

### Acceptance criteria

- The Stage 1 result is deterministic and reproducible from a committed script.
- Every stage states explicitly what it can and cannot claim.
- Stage 3 either finds suitable published data or states Stage 2's assumptions as assumptions.
- Full tests, Ruff, mypy, and validators pass.

### Dependencies

- Stage 1 can run directly on the closed detector chapter's outputs
  (`docs/phase3_heldout_design.md`).
- Stage 2 should express reviewer input in terms of findings and evidence bundles once Milestone 5
  (#7) lands.
