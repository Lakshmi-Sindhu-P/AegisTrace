## State: DONE

The finding stands as recorded, and its "Next" step has now been completed.

### Next step resolved

The recommended reframe was approved as policy on 2026-10-08 and executed:

1. **Reframe approved.** The Phase 3 evaluation diagnosis is no longer a proposal: the frozen
   threshold is measured on capture-grouped held-out captures and the unknown-label workload is
   reported separately, instead of selecting a threshold under a labeled-population-relative cap.
   Recorded in `MEMORY.md`.
2. **Unknown-label workload measured.** `scripts/report_phase3_unknown_workload.py` produces Evidence
   5 in `docs/phase3_evaluation_diagnosis.md`. At the frozen threshold `0.20`, the frozen balanced
   Random Forest raises `1,189,850` alerts on `2,720,880` unlabeled rows (43.7% of unlabeled traffic)
   and `1,302,368` across all `2,886,156` rows.
3. **Capture-grouped held-out battery run.** Issue #6 (closed): four exam captures measured at the
   frozen threshold with no threshold search. Within training families the policy transfers almost
   perfectly (50 Neris: precision `0.9993`, recall `0.9987`); unseen families degrade non-uniformly
   (49 Murlo precision `0.4694`; 54 Virut recall `0.4515`). Results in
   `docs/phase3_heldout_design.md`.

### Consequence for the original claim

The mechanism recorded here is confirmed rather than hypothetical: the frozen threshold does achieve
the ~99% labeled recall this issue predicted, the reported ~27% operating-point recall was a property
of the workload cap, and the held-out battery now supplies exactly the capture-grouped measurement
this issue asked for. The cap arithmetic (`20 / 67.8 = 29.5%` ceiling, observed `26.9%`) is unchanged
and still correct.

Nothing in this diagnostic was invalidated, and no threshold, artifact, or frozen policy was changed
by it.

Refs: #6 (closed); `docs/phase3_evaluation_diagnosis.md` Evidence 5; `docs/phase3_heldout_design.md`.
