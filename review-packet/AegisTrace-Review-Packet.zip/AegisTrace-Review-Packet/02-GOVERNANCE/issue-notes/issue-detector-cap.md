State: VALIDATING — read-only diagnostic, 2026-10-08. No policy, artifact, or code was modified.

## Problem
The Phase 3 stability study reports operating-point recall around 27% and a 68,353-case all-model residual, which has been read as "the detector is weak." The repaired artifacts show that figure is an artifact of the evaluation policy, not of model discrimination.

## Evidence — data/evaluation/phase3_model_stability/stability_summary.json
Pooled labeled validation population: `support` 165,276 = `positive_count` 112,001 (67.8%) + `negative_count` 53,275.

Random Forest:
- threshold 0.20 (the frozen policy): precision 0.9903, recall 0.9949, TP 111,426, FP 1,092, FN 575, known_alerts 112,518 (680.8 per 1,000 labeled) — `eligible=False`.
- threshold 0.73 (selected operating point): precision 0.99987, recall 0.2685, TP 30,072, FP 4, FN 81,929, known_alerts 30,076 (182.0 per 1,000) — `eligible=True`.

HistGradientBoosting at threshold 0.20: precision 0.9954, recall 0.9931, FN 772.

Operating policy (same artifact): maximize recall subject to `precision >= 0.95` AND `alerts_per_1000_labeled_flows <= 200`.

## Mechanism
The labeled population is 67.8% positive. A cap of 200 alerts per 1,000 labeled flows permits flagging at most 20% of labeled rows, so even a perfect ranker can capture at most 20 / 67.8 = **29.5%** of positives. The observed 26.9% is ~91% of that mathematical ceiling. The cap, not the model, is the binding constraint. `alerts_per_1000_labeled_flows` is population-dependent and behaves as a recall ceiling whenever the labeled set is mostly positive.

## Consequence
- The frozen threshold (0.20) already achieves ~99% recall at ~99% precision on labeled validation; it was excluded only because it exceeds the workload cap.
- The genuine open uncertainty is the **unknown-label population**: the hardening artifact records 186,269 alerts at the frozen threshold across 455,303 total rows, which have no authoritative class and cannot be scored.
- The rules detector is separately and genuinely weak (recall 0.0013); this finding concerns the supervised models only.

## Caveats
- Validation evidence only (captures 45/46/53/51); not a held-out or real-world generalization claim.
- Does not establish performance on the unknown population.

## Next
Reframe the detector chapter: measure at the frozen threshold on a capture-grouped held-out set and report the unknown-label workload separately, instead of selecting a threshold under a labeled-population-relative cap.
