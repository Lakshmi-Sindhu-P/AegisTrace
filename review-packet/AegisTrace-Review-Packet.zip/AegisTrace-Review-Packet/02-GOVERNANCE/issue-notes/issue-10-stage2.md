## Stage 2 — `VALIDATED`: the stage 1 refutation survives the sweep

Stage 1 compared **one** retrieval rule. Stage 2 replaces that rule with an explicit reviewer *policy*
and sweeps it, so a reviewer-policy artifact can no longer explain the negative result.

Commit `7458f3f`. Artifact `data/evaluation/phase3_reviewer_simulation/simulation_summary.json`,
sha256 `88120f046ad0b9c836828cde1e9c9b6a47a9e362a05255165925fc735ceda4ef`.

### The reviewer model — a policy, not a person

A reviewer works alerts from a queue ordered by the routing policy, up to a **shift budget** `B`, and
escalates iff `score >= S`. Alerts past `B` are never worked. Sweep: `S` ∈ {0.1, 0.2, 0.3, 0.5, 0.7},
`B` ∈ {10, 25, 50, 100, 200}, over `model_score` / `uncertainty` / `random` — 75 policies per capture,
**450** across the six captures. `oracle` is omitted: it reads ground-truth labels and is not an
achievable reviewer policy.

### Result

Uncertainty beats `model_score` at equal `(S, B)` in **0 of 6 captures**. `model_score` is the best
routing policy at every strictness and every shift budget on every capture. Best true escalations at
`B = 200`:

| Capture | model_score | uncertainty | random |
|---|---|---|---|
| 46 | 200 | 175 | 32 |
| 53 | 200 | 116 | 34 |
| 48 | 10 | 2 | 0 |
| 49 | 200 | 10 | 15 |
| 50 | 200 | 192 | 169 |
| 54 | 200 | 104 | 60 |

Random again beats uncertainty on capture 49 (15 vs 10), independently reproducing stage 1.

### A detector observation, recorded rather than smoothed over

On capture 48 at `S = 0.1, B = 200`, `model_score` yields only **10** true escalations although stage 1
retrieved **33** true positives in the top 200. Ranking parity between the two was verified — identical
ordering and tie-breaks. The cause is the escalation rule meeting the probability scale: roughly 23 of
those top-200 malicious rows carry a RandomForest probability below 0.1, so `score >= 0.1` never
escalates them. This is the same recall collapse the held-out battery recorded for capture 48, and it
means an absolute strictness threshold is a blunt instrument on a poorly-calibrated capture.

### Metric convention, stated to prevent misreading

`false_escalation_rate` here is `false_escalations / escalations` — the complement of precision —
**not** false escalations per alert reviewed. The implemented convention differs from the one
originally specified; it is recorded in the module docstring, the program document, and the registry
rather than left ambiguous.

### Stage 3 evidence base, and a caught error

`docs/human_factors_evidence.md` now bounds what the simulation may assume. Two sources were
re-fetched and their numbers read from source tables, which **caught a transcription error** in the
delegated scan: the IDS false-alarm experiment's per-alert time is a median of **13.44 s vs 18.76 s**
(mean 13.95 vs 19.25), not the "15.6 s vs 21.4 s" first reported. Its precision medians (0.80 vs 0.33)
are correct. A control fetch that returned empty was diagnosed as broken network egress in the review
shell, not missing sources, and that spurious "not found" result was discarded.

**Two quantities have no usable published source** and must remain explicit free assumptions:
alerts-per-shift **workload thresholds**, and **SOC-specific automation bias**. No AegisTrace result
may claim to model real reviewer load or real over-reliance.

### Boundary

The reviewer is a policy, not a person. No claim about analyst decision quality, over-reliance, trust
calibration, or automation bias. Unknown-label rows are excluded from every metric; no pooled figure
is reported. The shift budgets and strictness values are free assumptions.

Gate: **132 passed / 91.72%**, ruff and mypy clean (45 files), registry at 7 runs with 0 missing
artifacts.
