## State: PROPOSED — partly blocked on a human decision

Depends on an owner decision on LLM provider selection (see Dependencies). The provider-independent
parts (1, 2, and 5 below) can proceed without it.

### Objective

Build the LLM triage layer on top of the Milestone 5 spine: a frozen evaluation corpus, two
independently frozen assessor roles that cannot see each other's work, and a deterministic engine
that adjudicates their disagreement without an LLM in the loop.

### Why

This is the project's sharpest defensible research gap. The landscape scan (`docs/research_landscape.md`)
found the "LLM-assisted SOC investigation" area crowded, with closest prior art treating multi-agent
LLM triage as agents that **collaborate** over shared evidence. No security-triage work was found
that treats *mutual blindness between frozen assessors* as the experimental variable, with their
disagreement itself as the escalation signal. Milestone 5 exists precisely so that this layer has
findings and evidence bundles to reason over; the project rule forbids LLM triage before them.

### Scope

1. **`TriageAssessment` schema** per `docs/architecture.md`: triage id, evidence-bundle version,
   finding ids, summary, proposed category/severity, a non-probabilistic confidence statement, cited
   evidence ids, uncertainties, unsupported-claim flags, next step, provider/model/prompt metadata,
   raw structured response reference, creation time, review status, and a role field
   (`triage_analyst` or `expert_adjudicator`). It must accept `insufficient_evidence` as a valid
   outcome, and an invalid or uncited response must be stored as a failed attempt rather than coerced
   into a valid assessment.
2. **LLM evaluation corpus** built deterministically from Milestone 5 findings and evidence bundles.
   Frozen, digest-recorded, and reproducible from the committed builder.
3. **Provider selection** — the owner decides. Record the choice, its cost and data-governance
   implications, and the version pinning.
4. **Two independently frozen assessor roles** with separate input snapshots, so neither can observe
   the other's output, shared scratch state, or ordering.
5. **Deterministic agreement engine**: a `TriageComparison` record per architecture, retaining raw
   structured outputs, validator results, and disagreement reasons. The engine is deterministic code,
   not a model, and is what converts disagreement into an escalation signal.

### Out of scope

- No autonomous blocking, quarantine, or remediation action of any kind.
- No model fusion.
- No UI (that is the following milestone).
- No change to the frozen detector policy.

### Acceptance criteria

- Two assessors given the same bundle cannot observe each other's output; a test proves the isolation.
- The agreement engine is deterministic: identical inputs produce byte-identical comparisons.
- An uncited or malformed LLM response is stored as a failed attempt, never as a valid assessment.
- `insufficient_evidence` is representable end to end.
- Full tests, Ruff, mypy, and validators pass.

### Dependencies

- **Milestone 5 (Issue #7) — closed.** Findings, evidence bundles, and claim verification now exist.
- **Human decision required:** which LLM provider and model to freeze, including cost and the data
  governance of sending security evidence to a third party. `MEMORY.md` records that no provider has
  been selected, and provider choice is a high-impact governance decision that no agent may make
  autonomously.
