## Transport boundary — `CURRENT / IMPLEMENTED`, offline only. Issue stays `BLOCKED_HUMAN`.

Commit `f0f9c9f`. The blocker is unchanged and is still a human decision. What changed is that the
gate is now **enforced by the code** rather than asserted in a JSON file.

### Why this was buildable without unblocking anything

The blocker has two parts: **provider access** (no client, no credential path) and **assessor
independence** (no pairing with two distinct model families). Neither is resolved here.

What was missing was the *seam* — `raw_response` was consumed by `build_assessment` everywhere and
produced by nothing. A seam can be built offline. Adding a network client or a credential path is a
dependency and secret-handling decision, and neither was touched.

### The gate is a refusal, not a warning

`assert_provider_permitted` raises `PermissionError` for any descriptor requiring egress unless the
freeze artifact's status is in `APPROVED_EGRESS_FREEZE_STATUSES` — a small allowlist that
**deliberately excludes `BLOCKED_HUMAN`**.

Verified by exercising it, not by reading it:

| Descriptor | Freeze status | Observed behaviour |
|---|---|---|
| `REMOTE`, requires egress | `BLOCKED_HUMAN` (the repo's current value) | **refused** — `PermissionError` |
| `OFFLINE_STUB`, no egress | `BLOCKED_HUMAN` | permitted |
| `REMOTE`, requires egress | `APPROVED` | permitted |

The gate opens **and closes** with the human decision. It is not stuck shut, so approving the run is a
one-field change rather than a code change.

**No network-capable import exists in either new module.** The complete import set is `hashlib`,
`json`, `collections.abc`, `datetime`, `enum`, `typing`, `uuid`, `pydantic`, and existing
`aegistrace` modules.

### Structural guarantees

- An `OFFLINE_*` response can never claim `synthetic=False`, and a `REMOTE` descriptor can never
  declare `requires_egress=False`. Self-contradictory descriptors are rejected at construction.
- `run_independent_triage` builds each snapshot **once** and sends the byte-identical digest to both
  roles. A digest mismatch is recorded as an **abort**, not compared — comparing two different inputs
  would measure the inputs, not the assessors.
- Budget exhaustion is recorded as an abort with a reason, not raised as an exception, so a partially
  completed run cannot be mistaken for a complete one.
- The orchestrator never writes to disk and never mutates the incoming bundles.

### The one-off audit is now a permanent test

The egress audit was performed by hand once. A hand audit is a claim about one afternoon, not a
property of the code, so it is now `tests/test_snapshot_leakage.py`.

Unique sentinel tokens are written into the **raw input events**, and the tests assert they reach
neither the bundle nor the snapshot. The first version of this file was **caught being vacuous**: it
asserted the label was absent from the snapshot, but the label is dropped before the bundle is even
built, so the assertion proved nothing. It now asserts the whole chain and fails loudly if the
fixture stops containing label material.

The suite also pins that network addresses **do** reach the snapshot, so stripping them later is a
deliberate, visible change rather than a silent one.

### Stale status corrected

The freeze artifact still said `"transport_status": "NOT IMPLEMENTED - no client exists"`. Repository
evidence now contradicts that, so it was corrected — and `status` remains `BLOCKED_HUMAN` because the
egress decision itself is still open. `measured_spend` remains zero.

### Still needed from the owner

1. Designate the two assessor configurations.
2. Approve a credential path.
3. Set the freeze status to an approved value — this single field is the switch that permits egress.

Or approve deferring the run. Nothing has been sent anywhere.

Gate: **161 passed / 91.98%**, ruff and mypy clean (47 files).
