## Stage 1 — `IN_PROGRESS`

Starting stage 1 (decision-theoretic replay) per the approved order 1 → 3 → 4. No human participants,
no new data collection, no external contact.

**Question.** Given a fixed reviewer budget `K`, does routing alerts by the project's uncertainty
signal retrieve more true positives than routing by model score alone?

**Inputs (all already local and verified present).** The frozen policy's own training captures
(52, 47), the validation pool (46, 53), and the four measured battery captures (48, 49, 50, 54).
Capture 44 remains excluded: 4,710,639 rows exceeds available RAM, as recorded in
`docs/phase3_heldout_design.md`.

**Policies.** `model_score` (descending), `uncertainty` (ascending distance from the frozen
threshold), `random` (seeded negative control), `oracle` (upper bound).

**Why `random` matters.** A routing policy that beats `model_score` is only meaningful if it also
beats `random`. Without that control, a win could simply mean the model's ranking carries no signal
on that capture.

**Measurement constraints.**
- No threshold change, no refit, no feature change. This is measurement only.
- `UNKNOWN`-label rows are excluded from the labeled evaluation and reported separately. They are
  never counted as false positives.
- Each capture is reported separately. The battery showed family-dependent failure (Murlo and Virut
  both collapsed on different axes), so a pooled figure would hide precisely the effect of interest.
  Any pooled number will be labelled as losing capture identity.
- Training data is the frozen policy's own training captures, so no exam capture informs fitting.

**What this can claim.** "On these captures, routing by X reaches Y more true positives than routing
by Z at a budget of K alerts."

**What this forbids.** Anything about human decision quality, analyst behaviour, over-reliance,
automation bias, or real SOC outcomes. This measures the value of the **routing**, not human
cognition. That boundary is enforced in the artifact's own limitations block, not just stated here.
