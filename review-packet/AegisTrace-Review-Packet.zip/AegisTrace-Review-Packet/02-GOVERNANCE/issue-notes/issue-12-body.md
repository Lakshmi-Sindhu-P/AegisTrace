## State

`IN_PROGRESS` — deterministic review layer implemented and verified; the minimal local UI remains.

## Problem

The project's central promise is that nothing acts without human interference. Triage produces two
independent assessments and a deterministic comparison, but until now there was no contract for what
a human *does* with them: no reviewer tier, no disposition, and no rule preventing a correction from
silently erasing the earlier record.

## Scope

Provider-independent and fully deterministic. No LLM call, no network.

1. **Review contracts** (`src/aegistrace/schemas/review.py`) — `ReviewTier`, `ReviewDecision`,
   `EscalationState`, `MachineCheck`, `TierAssignment`, `HumanReview`, `ReviewHistory`.
2. **Deterministic tier assignment** (`src/aegistrace/review/tiers.py`) — Tier A machine checks of
   evidence mechanics, Tier B guided review, Tier C expert judgement, Tier D insufficient evidence.
3. **Append-only history** (`src/aegistrace/review/history.py`) — corrections supersede the latest
   review rather than overwriting it.
4. **Minimal local UI** — not started.

## Tier rules (label-free, no model opinion)

- every admissible assessment abstained → Tier D
- an assessor failed, or the assessors disagreed → Tier C
- agreed but flagged uncertainty or unsupported claims → Tier B
- agreed with no flags and all machine checks passing → Tier A

A failing machine check can raise a tier but never lower one.

## Acceptance criteria

- [x] An uncited or malformed assessment cannot become a `HumanReview` subject (`#11` guarantees this).
- [x] Tier assignment is a pure function of the assessment/comparison records; no research label is read.
- [x] `append_review` rejects duplicates, foreign subjects, orphan supersessions, and a second review
      that does not supersede the latest.
- [x] `HumanReview` refuses to be constructed as a `REVISE` without a supersession link.
- [x] Gate green: 112 tests, 91.96% coverage, ruff clean, mypy clean (43 files), all four validators pass.
- [ ] Minimal local UI for review submission.

## Excluded by design

Severity interpretation, prioritisation, automated disposition, notification, and any write path that
acts on a system under observation. This milestone records human judgement; it does not automate it.
